// import express module
const express = require("express");
const { addUsers,loadUsers, loadUser } = require("./service.js");
const app = express();

let users = [];

app.use(express.json());
app.post("/adduser", (req, res) => {
  const newUser = req.body;
  addUsers(newUser.id, newUser.name, newUser.city, (err, id) => {
    res.send(" user added ");
  });
});

app.get("/loadusers", (req, res) => {
  loadUsers((err,users)=>{
  res.send(users)
})
});

app.get("/loaduser/:id", (req, res) => {
  const uid = parseInt(req.params.id);
  loadUser(uid,(err,user)=>{
    if(err) return res.send("Error")
      res.send(user)
  })
  
});

app.listen(3000, () => {
  console.log("Server is ready...!");
});


