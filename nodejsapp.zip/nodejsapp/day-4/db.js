// it maintain database connection

const sqlite3= require('sqlite3').verbose()

// create db connection

const db= new sqlite3.Database("users.db")

// create a table

db.run
(
    `create table if not exists users(id INTEGER,name TEXT,city TEXT)`
)

module.exports =db