
const dbapp= require('./db.js')

// function to add data into table

function addUsers(id,name,city,callback){
    dbapp.run('insert into users (id,name,city) values (?,?,?)',[id,name,city],function(err){
        if(err) return callback(err)
            callback(null,this.lastID)
    })
}

function loadUsers(callback){
    dbapp.all("select * from users",[],(err,rows)=>{
          if(err) return callback(err)
           callback(null,rows) 
    })
}

function loadUser(id,callback){
    dbapp.get("select * from users where id=?",[id],(err,rows)=>{
          if(err) return callback(err)
           callback(null,rows) 
    })
}
module.exports={addUsers,loadUsers,loadUser}


// function to load data from table


/* 
// function to load specific data from table




function deleteStudent(id,callback){
    dbapp.run("delete from students where id=?",[id],function(err){
          if(err) return callback(err)
           callback(null,this.changes) 
    })
}

function updateStudent(id,subject,callback){
    dbapp.run("update students set subject=? where id=?",[subject,id],function(err){
          if(err) return callback(err)
           callback(null,this.changes) 
    })
}



module.exports={addStudent,loadStudents,loadStudent,deleteStudent,updateStudent} */