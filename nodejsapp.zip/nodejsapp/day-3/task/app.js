var express = require("express");
const {addStudent,loadStudents,loadStudent,deleteStudent, updateStudent} = require('./service.js')
app = express();
app.use(express.json());
let students = [];
 // add this to DB

app.post("/addstudent", (req, res) => {
  const newUser = req.body;
  addStudent(newUser.id,newUser.name,newUser.subject,(err,id) =>{
    res.send('user added' + id)
  })

});
// load from DB
app.get("/students", (req, res) => {
  loadStudents((err,students) =>{
  if(err) return res.send("Error")
  
  res.send(students);
})
});
//load only specific user
app.get("/loadstudent/:id", (req, res) => {
  const uid = parseInt(req.params.id);
  loadStudent(uid,(err,student)=>{
    if(err) return res.send("Error")
      res.send(student)
  })
  
});


//delete only specific user
app.delete("/deletestudent/:id", (req, res) => {
  const uid = parseInt(req.params.id);
  deleteStudent(uid,(err,changes)=>{
    if(err) return res.send("Error")
      if(changes === 0) return res.send("No Student Found")
      res.send("Student Deleted")
  })
  
});


app.put("/updatestudent/:id", (req, res) => {
  const uid = parseInt(req.params.id);
  const subject= req.body.subject
  updateStudent(uid,subject,(err,changes)=>{
    if(err) return res.send("Error")
      if(changes === 0) return res.send("No Student Found")
      res.send("Student updated")
  })
  
});


app.listen(3000, () => {
  console.log("server is ready");
});
