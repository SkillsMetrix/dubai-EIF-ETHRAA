
const dbapp= require('./db.js')

// function to add data into table

function addStudent(id,name,subject,callback){
    dbapp.run('insert into students (id,name,subject) values (?,?,?)',[id,name,subject],function(err){
        if(err) return callback(err)
            callback(null,this.lastID)
    })
}
// function to load data from table


function loadStudents(callback){
    dbapp.all("select * from students",[],(err,rows)=>{
          if(err) return callback(err)
           callback(null,rows) 
    })
}

// function to load specific data from table

function loadStudent(id,callback){
    dbapp.get("select * from students where id=?",[id],(err,rows)=>{
          if(err) return callback(err)
           callback(null,rows) 
    })
}


function deleteStudent(id,callback){
    dbapp.run("delete from students where id=?",[id],function(err){
          if(err) return callback(err)
           callback(null,this.changes) 
    })
}

function updateStudent(id,subject,callback){
    dbapp.run("update students set subject=? where id=?",[subject,id],function(err){
          if(err) return callback(err)
           callback(null,this.changes) 
    })
}



module.exports={addStudent,loadStudents,loadStudent,deleteStudent,updateStudent}