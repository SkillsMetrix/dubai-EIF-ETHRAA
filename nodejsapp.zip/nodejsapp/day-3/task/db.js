// it maintain database connection

const sqlite3= require('sqlite3').verbose()

// create db connection

const db= new sqlite3.Database("students.db")

// create a table

db.run
(
    `create table if not exists students(id INTEGER,name TEXT,subject TEXT)`
)

module.exports =db