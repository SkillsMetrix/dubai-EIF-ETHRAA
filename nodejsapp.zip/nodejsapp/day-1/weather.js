
const axios= require('axios')

const city="dubai"

const API_KEY='b3aaa0b3323c0baab93aff38f75b44cb'

async function getWeather(){


const URL=`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`

console.log("Loading Weather..........!");
const response= await axios.get(URL)
return response.data

}
// this makethis function available to the other files
module.exports={getWeather}
