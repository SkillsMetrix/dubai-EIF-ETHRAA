const {getWeather} =require('./weather.js')

getWeather()
.then(data =>{
    console.log(`City : ${data.name}`);
        console.log(`Temprature : ${data.main.temp}`);
            console.log(`Description : ${data.weather[0].description}`);


    
})