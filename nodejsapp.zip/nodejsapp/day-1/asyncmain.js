const {readFromData} = require('./asyncfile.js')

readFromData()
.then(data =>{
    console.log("File Data ",data);
    
})