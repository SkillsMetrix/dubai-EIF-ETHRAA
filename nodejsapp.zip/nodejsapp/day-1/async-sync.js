
// blocking example (NodeJS comes with preloaded modules)

const fs= require('fs')

console.log('starting sync read....!');

// read the file synchronous

const dataSync= fs.readFileSync('test.txt','utf8')
console.log(dataSync);

console.log('FIle reading is over sync');

console.log("=======================================================");

console.log('starting async read....!');
// read the file asynchronous using callback
 fs.readFile('test.txt','utf8',(err,data)=>{
    console.log(data);
    
})
 

console.log('FIle reading is over async');

