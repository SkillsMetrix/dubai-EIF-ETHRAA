
const axios= require('axios')

const city="dubai"

const API_KEY='b3aaa0b3323c0baab93aff38f75b44cb'

const URL=`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`

console.log("Loading Weather..........!");

axios.get(URL)
.then(response =>{
    const data= response.data
    console.log("City ", data.name);
        console.log("Temp ", data.main.temp);

    
})
