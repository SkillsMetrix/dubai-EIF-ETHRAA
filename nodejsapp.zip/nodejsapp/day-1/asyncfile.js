const fs = require("fs").promises;

async function readFromData() {
  const data = await fs.readFile("test.txt", "utf8");
  return data;
}

module.exports = { readFromData };
