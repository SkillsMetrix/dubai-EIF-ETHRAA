import axios from "axios";

const BASE_URL =
"http://localhost:8080/bank";

export const registerUser =
(data) =>
axios.post(
`${BASE_URL}/register`,
data
);

export const loginUser =
(data) =>
axios.post(
`${BASE_URL}/login`,
data
);

export const depositMoney =
(id, amount) =>
axios.put(
`${BASE_URL}/deposit/${id}/${amount}`
);

export const withdrawMoney =
(id, amount) =>
axios.put(
`${BASE_URL}/withdraw/${id}/${amount}`
);