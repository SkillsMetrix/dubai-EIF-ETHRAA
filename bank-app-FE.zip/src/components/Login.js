import React, { useState }
from "react";

import { loginUser }
from "../services/bankService";

import { useDispatch }
from "react-redux";

import { setUser }
from "../features/authSlice";

import { useNavigate }
from "react-router-dom";

function Login() {

    const dispatch = useDispatch();

    const navigate = useNavigate();

    const [form, setForm] =
    useState({

        username: "",
        password: ""
    });

    const handleSubmit =
    async (e) => {

        e.preventDefault();

        try {

            const response =
            await loginUser(form);

            dispatch(
                setUser(response.data)
            );

            navigate("/dashboard");

        } catch(error) {

            alert(
                error.response.data.message
            );
        }
    };

    return (

        <div className="container mt-5">

            <div className=
            "card p-4 shadow">

                <h3>Login</h3>

                <form
                onSubmit={handleSubmit}>

                    <input
                    className=
                    "form-control mb-3"

                    placeholder="Username"

                    onChange={(e)=>
                    setForm({
                        ...form,
                        username:
                        e.target.value
                    })}
                    />

                    <input
                    type="password"

                    className=
                    "form-control mb-3"

                    placeholder="Password"

                    onChange={(e)=>
                    setForm({
                        ...form,
                        password:
                        e.target.value
                    })}
                    />

                    <button
                    className=
                    "btn btn-primary">

                        Login
                    </button>

                </form>

            </div>

        </div>
    );
}

export default Login;