import React, { useState }
from "react";

import {
    useDispatch,
    useSelector
}
from "react-redux";

import {
    depositMoney,
    withdrawMoney
}
from "../services/bankService";

import {
    setUser,
    logout
}
from "../features/authSlice";

import { useNavigate }
from "react-router-dom";

function Dashboard() {

    const user =
    useSelector(
    (state)=>state.auth.user
    );

    const dispatch = useDispatch();

    const navigate = useNavigate();

    const [amount, setAmount] =
    useState("");

    const deposit = async () => {

        const response =
        await depositMoney(
            user.id,
            amount
        );

        dispatch(
            setUser(response.data)
        );
    };

    const withdraw = async () => {

        try {

            const response =
            await withdrawMoney(
                user.id,
                amount
            );

            dispatch(
                setUser(response.data)
            );

        } catch(error) {

            alert(
                error.response.data.message
            );
        }
    };

    const handleLogout = () => {

        dispatch(logout());

        navigate("/login");
    };

    return (

        <div className="container mt-5">

            <div className=
            "card p-5 shadow">

                <div className=
                "d-flex justify-content-between">

                    <h2>
                        ABC Banking Dashboard
                    </h2>

                    <button
                    className="btn btn-dark"

                    onClick={handleLogout}>

                        Logout
                    </button>

                </div>

                <hr />

                <h4>
                    Welcome {user.username}
                </h4>

                <h2 className=
                "text-success mt-3">

                    Balance :
                    ₹ {user.balance}

                </h2>

                <input
                type="number"

                className=
                "form-control mt-4"

                placeholder="Enter Amount"

                onChange={(e)=>
                setAmount(e.target.value)}
                />

                <div className="mt-4">

                    <button
                    className=
                    "btn btn-success me-3"

                    onClick={deposit}>

                        Deposit
                    </button>

                    <button
                    className=
                    "btn btn-danger"

                    onClick={withdraw}>

                        Withdraw
                    </button>

                </div>

            </div>

        </div>
    );
}

export default Dashboard;