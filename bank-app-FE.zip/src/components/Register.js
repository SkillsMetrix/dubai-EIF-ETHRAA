import React, { useState }
from "react";

import { registerUser }
from "../services/bankService";

import { useNavigate }
from "react-router-dom";

function Register() {

    const navigate = useNavigate();

    const [form, setForm] =
    useState({

        username: "",
        password: ""
    });

    const handleSubmit =
    async (e) => {

        e.preventDefault();

        await registerUser(form);

        alert(
            "Registration Successful"
        );

        navigate("/login");
    };

    return (

        <div className="container mt-5">

            <div className=
            "card p-4 shadow">

                <h3>Register</h3>

                <form
                onSubmit={handleSubmit}>

                    <input
                    className=
                    "form-control mb-3"

                    placeholder="Username"

                    onChange={(e)=>
                    setForm({
                        ...form,
                        username:
                        e.target.value
                    })}
                    />

                    <input
                    type="password"

                    className=
                    "form-control mb-3"

                    placeholder="Password"

                    onChange={(e)=>
                    setForm({
                        ...form,
                        password:
                        e.target.value
                    })}
                    />

                    <button
                    className=
                    "btn btn-success">

                        Register
                    </button>

                </form>

            </div>

        </div>
    );
}

export default Register;