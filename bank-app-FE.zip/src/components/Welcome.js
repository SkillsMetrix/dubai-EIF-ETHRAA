import React from "react";

import { Link }
from "react-router-dom";

function Welcome() {

    return (

        <div className="container mt-5">

            <div className=
            "card p-5 text-center shadow">

                <h1>
                    Welcome to ABC Banking
                </h1>

                <p className="lead">
                    Secure Banking Application
                </p>

                <div className="mt-4">

                    <Link
                    to="/login"
                    className=
                    "btn btn-primary me-3">

                        Login
                    </Link>

                    <Link
                    to="/register"
                    className=
                    "btn btn-success">

                        Register
                    </Link>

                </div>

            </div>

        </div>
    );
}

export default Welcome;