// function

function showMsg(){
    console.log('Welcome to JS');
    
}

function showAlert(){
    alert(' your browser memory is full !!')
}
function collectInput(){
    uname=document.getElementById("uname").value
    document.getElementById("show").innerHTML=uname
     
    
}