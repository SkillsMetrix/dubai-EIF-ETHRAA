
const iconElement=document.querySelector('.weather-icon')
const locationIcon=document.querySelector('.location-icon')
const tempElement=document.querySelector('.temprature-value p')
const descElement=document.querySelector('.temprature-description p')
const locationElement=document.querySelector('.location p')
const notElement=document.querySelector('.notification')

var input= document.getElementById('search')
let city=""
let latitute=0.0
let longitude=0.0

input.addEventListener("keyup", function(event){

    if(event.keyCode ===13){
        event.preventDefault()
        city = input.value
        console.log(city);
        //call the func
        getWeatherFromCity(city)
        
    }
})
// js object
const weather={}

weather.temprature={
    unit: 'celsius'
}
const KELVIN=273
const key='b3aaa0b3323c0baab93aff38f75b44cb'

locationIcon.addEventListener("click",function (event){
    console.log('user clicked')
    
})
// search with city
function getWeatherFromCity(city){
let api=`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${key}`
// its a function to make API Call to the URLS
fetch(api)
.then(function(response){
    //console.log(response.json());
    let data= response.json()
    return data
    
})
.then(function(data){
    weather.temprature.value=Math.floor(data.main.temp -KELVIN)
    weather.description=data.weather[0].description
    weather.iconId= data.weather[0].icon
    weather.city=data.name
    weather.country=data.sys.country

})
.then(function(){
    displayWeather()
})
}
//checking the lat and log while loading the browser
navigator.geolocation.getCurrentPosition(setPosition)
function setPosition(position){
     latitute= position.coords.latitude
     longitude=position.coords.longitude
     getWeather(latitute,longitude)
}
// search with current location
function getWeather(latitute,longitude){
let api=`https://api.openweathermap.org/data/2.5/weather?lat=${latitute}&lon=${longitude}&appid=${key}`
 fetch(api)
.then(function(response){
    //console.log(response.json());
    let data= response.json()
    console.log(data);
    
    return data
    
})
.then(function(data){
    weather.temprature.value=Math.floor(data.main.temp -KELVIN)
    weather.description=data.weather[0].description
   weather.iconId= data.weather[0].icon
   weather.humidity=data.main.humidity
    weather.city=data.name
    weather.country=data.sys.country

})
.then(function(){
    displayWeather()
})
}

function displayWeather(){
    iconElement.innerHTML=`<img src="icons/${weather.iconId}.png"/>`
    tempElement.innerHTML=`${weather.temprature.value} *<span>C</span>`
    descElement.innerHTML=`${weather.description} - <span>Humidity: ${weather.humidity}%</span>`
    locationElement.innerHTML=`${weather.city}, ${weather.country}`
}