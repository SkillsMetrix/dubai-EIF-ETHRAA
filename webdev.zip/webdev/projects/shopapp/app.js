

// fetch products

fetch("https://fakestoreapiserver.reactbd.org/api/products")
.then(res =>  res.json())
.then(data => showProducts(data.data))

function showProducts(products){
   
    
    let html=""
    products.forEach(p =>{
        html += `
        <div class="card"> 
        <div>
        <img src="${p.image}"/>
        <h4>${p.title}...</h4>
        <p>${p.price}$</p>
        <button onclick='addToCart(${JSON.stringify(p)})'>Add To Cart</button>
        </div>
        
        </div>
        
        `
    })
    document.getElementById("products").innerHTML=html
}
let cart=JSON.parse(localStorage.getItem('cart')) || []
function addToCart(product){
    cart.push({...product,qty:1})

   localStorage.setItem("cart",JSON.stringify(cart))
   updateCount()
    
}
function updateCount(){
    let total= cart.reduce((sum,i)=> sum + i.qty,0)
    document.getElementById('count').innerText=total
}
