package com.eif.springboot_app;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public class UserService {
	ArrayList<Employee> al= new ArrayList<Employee>();
	
	public void addUser(Employee emp) {
	al.add(emp);
	
}}
