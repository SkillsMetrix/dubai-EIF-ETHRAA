package com.eif.springboot_app;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/*@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString*/
public class Employee {
	
	private String userName;
	private String password;
	private String email;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Employee [userName=" + userName + ", password=" + password + ", email=" + email + "]";
	}
	
	
	
}