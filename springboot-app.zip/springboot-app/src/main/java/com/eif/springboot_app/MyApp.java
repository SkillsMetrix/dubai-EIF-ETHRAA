package com.eif.springboot_app;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/eif")
public class MyApp {
	
	@Autowired
	private UserService service;

	@GetMapping("/login")
	public String login() {
		return "welcome to login";
	}
	
	@PostMapping("/register")
	public String register(@RequestBody Employee emp) {
		service.addUser(emp);
		 
		
		return "welcome to register";
	}

}
