package com.bank.service;

import com.bank.entity.Account;
import com.bank.entity.UserKYC;
import com.bank.exception
        .AccountNotFoundException;

import com.bank.exception
        .InsufficientBalanceException;

import com.bank.exception
        .InvalidCredentialsException;
import com.bank.exception.ReceiverNotFoundException;
import com.bank.repository.AccountRepository;
import com.bank.repository.UserKYCRepository;

import org.springframework.beans.factory.annotation
        .Autowired;

import org.springframework.stereotype.Service;

@Service
public class AccountService {

    @Autowired
    private AccountRepository repository;
    @Autowired
    private UserKYCRepository kycRepository;

    public Account register(
            Account account) {

        account.setBalance(0.0);

        return repository.save(account);
    }

    public Account login(
            String username,
            String password) {

        Account account =
                repository
                .findByUsernameAndPassword(
                        username,
                        password
                );

        if(account == null) {

            throw new
                    InvalidCredentialsException(
                    "Invalid Credentials"
            );
        }

        return account;
    }

    public Account deposit(
            Long id,
            Double amount) {

        Account account =
                repository.findById(id)
                .orElseThrow(() ->
                        new
                        AccountNotFoundException(
                                "Account Not Found"
                        )
                );

        account.setBalance(
                account.getBalance() + amount
        );

        return repository.save(account);
    }

    public Account withdraw(
            Long id,
            Double amount) {

        Account account =
                repository.findById(id)
                .orElseThrow(() ->
                        new
                        AccountNotFoundException(
                                "Account Not Found"
                        )
                );

        if(account.getBalance() < amount) {

            throw new
                    InsufficientBalanceException(
                    "Insufficient Balance"
            );
        }

        account.setBalance(
                account.getBalance() - amount
        );

        return repository.save(account);
    }
    
    
    public Account transferFunds(Long senderId,String emiratesdId,Double amount) {
    	
    	// find sender acc
    	
    	Account sender= repository.findById(senderId)
    			.orElseThrow(()-> new AccountNotFoundException("sender not found"));
    	// validate balance
    	if(sender.getBalance() < amount) {
    		throw new InsufficientBalanceException("Insuffieent Balance");
    	}
    	//find Receiver KYC
    	UserKYC reUserKYC=kycRepository.findByEmiratesId(emiratesdId);
    	if(reUserKYC == null) {
    		throw new ReceiverNotFoundException("Receiver Emirated ID not Found");
    	}
    	// find receiver account
    	Account receiver= repository.findByUsername(reUserKYC.getUserName());
    	if(receiver == null) {
    		throw new ReceiverNotFoundException("Receiver account not Found");
    	}
    	//deduct sender balance
    	sender.setBalance(sender.getBalance() - amount);
    	receiver.setBalance(receiver.getBalance()+amount);
    	repository.save(sender);
    	repository.save(receiver);
    	return sender;
    	}
    	 
}