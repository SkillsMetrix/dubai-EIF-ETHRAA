package com.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bank.entity.UserKYC;
import com.bank.exception.KYCNotFoundException;
import com.bank.repository.UserKYCRepository;

@Service
public class UserKYCService {
	@Autowired
	private UserKYCRepository repository;
	
	public UserKYC saveKYC(UserKYC userKYC) {
		return repository.save(userKYC);
	}
	public UserKYC getKyc(String uname) {
		UserKYC kyc= repository.findByUserName(uname);
		if(kyc == null) {
			throw new KYCNotFoundException("NO KYC FOund..!");
		}
		return kyc;
	}

}
