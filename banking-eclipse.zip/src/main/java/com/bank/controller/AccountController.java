package com.bank.controller;

import com.bank.entity.Account;

import com.bank.service.AccountService;

import org.springframework.beans.factory.annotation
        .Autowired;

import org.springframework.web.bind.annotation.*;

@RestController

@RequestMapping("/bank")

@CrossOrigin(origins = "*")

public class AccountController {

    @Autowired
    private AccountService service;
    
    @PutMapping("/transfer/{senderId}/{emiratesId}/{amount}")
    public Account transferFunds(
    		@PathVariable Long senderId,
    		@PathVariable String emiratesId,
    		@PathVariable Double amount
    		) {
    	return service.transferFunds(senderId, emiratesId, amount);
    	
    }
    

    @PostMapping("/register")
    public Account register(
            @RequestBody Account account) {

        return service.register(account);
    }

    @PostMapping("/login")
    public Account login(
            @RequestBody Account account) {

        return service.login(
                account.getUsername(),
                account.getPassword()
        );
    }

    @PutMapping("/deposit/{id}/{amount}")
    public Account deposit(
            @PathVariable Long id,
            @PathVariable Double amount) {

        return service.deposit(id, amount);
    }

    @PutMapping("/withdraw/{id}/{amount}")
    public Account withdraw(
            @PathVariable Long id,
            @PathVariable Double amount) {

        return service.withdraw(id, amount);
    }
}