package com.bank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.entity.UserKYC;
import com.bank.service.UserKYCService;

@RestController

@RequestMapping("/kyc")

@CrossOrigin(origins = "*")
public class KYCController {
	@Autowired
	private UserKYCService service;
	
	@PostMapping("/save")
	public UserKYC saveKYC(@RequestBody UserKYC kyc) {
		return service.saveKYC(kyc);
		
	}
	@GetMapping("/{username}")
	public UserKYC getKYC(@PathVariable String username) {
		return service.getKyc(username);
	}

}
