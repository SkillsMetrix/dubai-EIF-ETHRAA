package com.bank.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bank.entity.UserKYC;
@Repository
public interface UserKYCRepository extends JpaRepository<UserKYC, String> {
	
	UserKYC findByUserName(String username);
	UserKYC findByEmiratesId(String emiratesId);

}
