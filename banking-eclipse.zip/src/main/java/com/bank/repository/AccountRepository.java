package com.bank.repository;

import com.bank.entity.Account;

import org.springframework.data.jpa.repository
        .JpaRepository;

public interface AccountRepository
        extends JpaRepository<Account, Long> {

    Account findByUsernameAndPassword(
            String username,
            String password
    );
    Account findByUsername(String username);
}