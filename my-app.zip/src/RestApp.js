import { useEffect, useState } from "react";
import axios from "axios";
const URL = "https://jsonplaceholder.typicode.com/users";
function LoadData() {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios
      .get(URL)
      .then((res) => res.data)
      .then((data) => {
        console.log(data);
      });
  }, []);

  return <div></div>;
}
export default LoadData