package fundstransfer;

public interface BankService {
	public void fundTransfer(Account src,Account dest,double amount) throws InsufficientFundsException;
}
