package fundstransfer;

public class BankMain {

	public static void main(String[] args) {
		Account ac1= new Account(101, 1000);
		Account ac2= new Account(102, 500);
		
		//System.out.println(ac1);
		//System.out.println(ac2);
		
		BankServiceImpl bil= new BankServiceImpl();
		try {
		bil.fundTransfer(ac1, ac2, 500);
		}catch (InsufficientFundsException e) {
			System.out.println(e.getMessage());
		}
	}
}
