package fundstransfer;

public class BankServiceImpl implements BankService {

	@Override
	public void fundTransfer(Account src, Account dest, double amount) throws InsufficientFundsException{
		 
		if(amount > src.getBalance()) {
			throw new InsufficientFundsException("No Enough Balance...!");
		}
		System.out.println("Current Balance in source account "+src.getBalance());
		System.out.println("Current Balance in destination account "+dest.getBalance());
		
		src.setBalance(src.getBalance()-amount);
		dest.setBalance(src.getBalance()+amount);
		System.out.println("Transferred "+amount + "from "+ +src.getAccNo() +" to "+ dest.getAccNo());
		
		System.out.println("Current Balance after in source account "+src.getBalance());
		System.out.println("Current Balance after in destination account "+dest.getBalance());
		
	}

}
