package bankingdemo;

public class BankAccount implements BankingOperations{
	
	double balance=1000;

	@Override
	public void deposit(double amount) {
		 balance= balance+amount;
		 System.out.println("Deposited "+ amount);
		
	}

	@Override
	public void withdraw(double amount) throws InvalidAmountException {
		if(amount <=balance) {
			balance= balance-amount;
			 System.out.println("Withdrawn "+ amount);
		}else {
			throw new InvalidAmountException("InSuffient funds Available");
		}}

	@Override
	public void checkBalance() {
		System.out.println("Balance: "+ balance);
		
	}
	public void performTransactions(TransactionType type, double amount)   {
		switch(type) {
		case DEPOSIT:
			deposit(amount);
			break;
		case WITHDRAW:
			try {
			withdraw(amount);
			}catch (InvalidAmountException e) {
				System.out.println(e.getMessage());
			}
			break;
		case CHECK_BALANCE:
			checkBalance();
			break;
		}
	}

}
