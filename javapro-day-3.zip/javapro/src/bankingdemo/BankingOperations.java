package bankingdemo;

public interface BankingOperations {

	public void deposit(double amount);
	public void withdraw(double amount) throws InvalidAmountException;
	public void checkBalance();
}
