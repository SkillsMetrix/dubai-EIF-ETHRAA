package exceptiondemo;

public class Student {
	private String studentName;
	private int marks;
	private int age;
	
	
	
	public int getAge() {
		
		return age;
	}
	public void setAge(int age) {
		if (age <18 ) 
			 throw new NumberFormatException("Age must be 18 and above");
		this.age = age;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks){
		 if (marks <0 || marks >100) 
			 throw new NumberFormatException("Marks must be correct");
		  this.marks = marks;
	}
	public void diaplayDetails() {
		System.out.println("Marks "+marks);
	}
	

}
