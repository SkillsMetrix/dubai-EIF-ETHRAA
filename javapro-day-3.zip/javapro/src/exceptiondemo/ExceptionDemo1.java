package exceptiondemo;

public class ExceptionDemo1 {

	public static void main(String[] args) {
		int result=0;
		try {
		 result= 10/0;
		}catch(ArithmeticException e) {
			System.out.println("cant divide with zero");
		}
		System.out.println(result);
	}

}
