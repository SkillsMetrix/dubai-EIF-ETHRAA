package exceptiondemo;

public class StudentMain {

	public static void main(String[] args) {
		Student stu1= new Student();
		stu1.setStudentName("Rahul");
		stu1.setAge(17);
		try {
		stu1.setMarks(-1);
		}catch (NumberFormatException e) {
			System.err.println(e.getMessage()); 
		}
		stu1.diaplayDetails();
	}

}
