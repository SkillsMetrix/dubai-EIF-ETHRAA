package exceptiondemo2;

public class StudentMain {

	public static void main(String[] args) {
		try {
		Student stu1= new Student("Saba",90,18);
		System.out.println(stu1);
		}catch (InvalidAgeException e) {
			System.out.println(e.getMessage());
		}catch (InvalidMarksException e) {
			System.out.println(e.getMessage());
		}
		
		 

}
}