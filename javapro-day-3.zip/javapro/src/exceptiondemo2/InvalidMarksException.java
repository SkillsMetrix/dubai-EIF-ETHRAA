package exceptiondemo2;

public class InvalidMarksException extends Exception{
	InvalidMarksException(String message){
		super(message);
	}
}
