package exceptiondemo2;

public class Student {
	private String studentName;
	private int marks;
	private int age;

	public Student(String studentName, int marks, int age) throws InvalidAgeException,InvalidMarksException {
		if (age < 18) {
			throw new InvalidAgeException("Age must be 18 or above");
		}
		if (marks < 0 || marks > 100)
			throw new InvalidMarksException("Marks must be correct");
		this.marks = marks;
		this.studentName = studentName;
		
		this.age = age;
	}

	@Override
	public String toString() {
		return "Student [studentName=" + studentName + ", marks=" + marks + ", age=" + age + "]";
	}

	
}
