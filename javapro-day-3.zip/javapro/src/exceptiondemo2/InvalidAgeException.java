package exceptiondemo2;

public class InvalidAgeException extends Exception{

	InvalidAgeException(String message){
		super(message);
	}
	
}
