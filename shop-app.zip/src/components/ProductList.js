import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { loadProducts } from "../redux/productSlice";
import { addToCart } from "../redux/Cart";
 

function ProductList() {
  const dispatch = useDispatch();
  const plist = useSelector((state) => state.pr.list);

  // call the function during loadtime
  useEffect(() => {
    dispatch(loadProducts());
  }, []);
  return (
    <div className="container mt-4">
      <div className="row">
        {plist.map((p) => (
          <div className="col-md-4 mb-4">
            <div className="card h-100 shadow">
              <img src={p.image} className="card-img-top p-3" height="200" />
              <div className="card-body d-flex flex-column">
                <h6>{p.title}</h6>
                <p className="fw-bold">${p.price}</p>
                <button onClick={()=>dispatch(addToCart())} className="btn btn-primary mt-auto">Add To Cart</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
export default ProductList;
