import {useSelector} from 'react-redux'
function Header(props) {
  const data= useSelector(state => state.cart.items)
  return (
    <nav className="navbar navbar-dark bg-dark">
      <div className="container">
        <span className="navbar-brand mb-0 h1">
          <i className="bi bi-people me-2"></i>
          MyAppStore

           🛒 Cart: <span className="badge bg-warning text-dark">
            {data.length}

        </span>
        </span>

      </div>
    </nav>
  );
}

export default Header;
