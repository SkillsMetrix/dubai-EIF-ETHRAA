
import productReducer from './productSlice'
import {configureStore} from '@reduxjs/toolkit'
import cartReducer from './Cart'

export const productStore= configureStore({
    reducer:{
        pr: productReducer,
        cart:cartReducer
    }
})
