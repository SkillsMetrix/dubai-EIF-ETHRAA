import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

export const loadProducts = createAsyncThunk("products/getProdutcs",
  async () => {
    const response = await fetch("https://fakestoreapi.com/products");
    const res = await response.json();
    return res;
  },
);

export const productsSlice = createSlice({
  name: "products",
  initialState: {
    list: [],
  },
  extraReducers: (builder) => {
    builder.addCase(loadProducts.fulfilled, (state, action) => {
      state.list = action.payload;
    
    });
  },
});
export default productsSlice.reducer;
