package javapro;

public class StaticMain {

	public static void main(String[] args) {
		 StaticandRegular.showCollage();
		 
		 StaticandRegular sr= new StaticandRegular();
		 StaticandRegular sr2= new StaticandRegular();
		 
		 sr.studentName="Amana";
		 sr2.studentName="Ghaith";
		 
		 sr.showStudentDetails();
		 sr2.showStudentDetails();
				 
		 
	}

}
