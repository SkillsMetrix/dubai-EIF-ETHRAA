package javapro;

public class StaticandRegular {

	// instance variable
	String studentName;

	// static var (class)
	static String collageName = "ABC Collage";
	
	// static method
	
	static void showCollage() {
		System.out.println("Collage "+ collageName);
	}
	
	void showStudentDetails() {
		System.out.println("Student " +studentName);
		System.out.println("Collage " +collageName);
	}

	
}
