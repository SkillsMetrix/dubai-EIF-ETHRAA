package javapro;

public class EmployeeCons {
	private int empId;
	private String empName;
	private String empCity;
	private String empDept;
	
	public EmployeeCons(int empId, String empName, String empCity, String empDept) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empCity = empCity;
		this.empDept = empDept;
	}
	 
	
	
	
}
