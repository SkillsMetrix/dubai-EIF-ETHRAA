package javapro;

public class EmployeeMain {

	public static void main(String[] args) {
		// create an object of Employee
		Employee emp = new Employee();

		emp.setEmpId(101);
		emp.setEmpName("salama");
		emp.setEmpCity("Dubai");
		emp.setEmpDept("HR");
		System.out.println(emp.getEmpName() + " " + emp.getEmpCity() + " " + emp.getEmpDept());

		emp = null;

		// create an object of Employee
		Employee emp2 = new Employee();

		emp2.setEmpId(102);
		emp2.setEmpName("Ghaith");
		emp2.setEmpCity("Dubai");
		emp2.setEmpDept("IT");
		System.out.println(emp2.getEmpName() + " " + emp2.getEmpCity() + " " + emp2.getEmpDept());
		emp2 = null;
		
		//-------------------Constructor Demo-----
		
		EmployeeCons ec= new EmployeeCons(101, "Shra", "NY", "IT");
		
		System.out.println(ec);
		
		

	}

}
