package javapro;

public class CollectData {

	public static void main(String[] args) {
		 
		int input= Integer.parseInt(args[0]);
		int input2= Integer.parseInt(args[1]);
		
		int result=input+input2;
		
		
		System.out.println("Addition is  " + result);
		
	}

}
