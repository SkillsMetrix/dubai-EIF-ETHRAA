package inheritencedemo;

public class PublicSectorBank extends Banking{

	@Override
	public int checkBalance() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void depositAmount() {
		 System.out.println("Amount deposited");
		
	}

	@Override
	public void withdrawAmount() {
		System.out.println("Amount withdrawn");
		
	}

	@Override
	public String applyCreditCard() {
		// TODO Auto-generated method stub
		return "credit card Applied in public bank";
	}

	 
	
	
	
	

}
