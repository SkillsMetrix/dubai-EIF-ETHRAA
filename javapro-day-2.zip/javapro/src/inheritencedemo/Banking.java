package inheritencedemo;

public abstract class Banking {
	
	public abstract int checkBalance();
	public abstract void depositAmount();
	public abstract void withdrawAmount();
	public abstract String applyCreditCard();
	public void openAccount() {
		System.out.println("optional method");
	}

}
