package bankingdemo;

public class BankingMain {

	public static void main(String[] args) {
		 BankAccount account= new BankAccount();
		 
		 account.performTransactions(TransactionType.CHECK_BALANCE, 0);
		 account.performTransactions(TransactionType.DEPOSIT, 500);
		 account.performTransactions(TransactionType.CHECK_BALANCE, 0);

	}

}
