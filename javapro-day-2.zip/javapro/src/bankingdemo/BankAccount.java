package bankingdemo;

public class BankAccount implements BankingOperations{
	
	double balance=1000;

	@Override
	public void deposit(double amount) {
		 balance= balance+amount;
		 System.out.println("Deposited "+ amount);
		
	}

	@Override
	public void withdraw(double amount) {
		if(amount <=balance) {
			balance= balance-amount;
			 System.out.println("Withdrawn "+ amount);
		}else {
			System.out.println("Insufficient Balance...!");
		}}

	@Override
	public void checkBalance() {
		System.out.println("Balance: "+ balance);
		
	}
	public void performTransactions(TransactionType type, double amount) {
		switch(type) {
		case DEPOSIT:
			deposit(amount);
			break;
		case WITHDRAW:
			withdraw(amount);
			break;
		case CHECK_BALANCE:
			checkBalance();
			break;
		}
	}

}
