package bankingdemo;

public enum TransactionType {

	DEPOSIT,
	WITHDRAW,
	CHECK_BALANCE
}
