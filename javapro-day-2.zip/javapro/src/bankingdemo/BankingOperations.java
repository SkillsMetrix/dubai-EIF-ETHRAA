package bankingdemo;

public interface BankingOperations {

	public void deposit(double amount);
	public void withdraw(double amount);
	public void checkBalance();
}
