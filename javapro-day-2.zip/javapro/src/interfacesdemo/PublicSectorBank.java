package interfacesdemo;

public class PublicSectorBank implements Banking,Insurance{

	@Override
	public int checkBalance() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void depositAmount() {
		 System.out.println("Amount deposited");
		
	}

	@Override
	public void withdrawAmount() {
		System.out.println("Amount withdrawn");
		
	}

	@Override
	public String applyCreditCard() {
		// TODO Auto-generated method stub
		return "credit card Applied in public bank";
	}

	@Override
	public void takeInsurance() {
		System.out.println("Insurance Taken");
		
	}

	 
	
	
	
	

}
