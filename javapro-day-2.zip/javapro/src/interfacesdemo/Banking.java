package interfacesdemo;

public interface Banking {

	public int checkBalance();

	public void depositAmount();

	public void withdrawAmount();

	public String applyCreditCard();
	

}
