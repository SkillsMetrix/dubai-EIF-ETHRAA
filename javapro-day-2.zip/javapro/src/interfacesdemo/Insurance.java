package interfacesdemo;

public interface Insurance {
	public void takeInsurance();

}
