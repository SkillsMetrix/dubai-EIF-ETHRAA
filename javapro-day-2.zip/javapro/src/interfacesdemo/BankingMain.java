package interfacesdemo;

public class BankingMain {

	public static void main(String[] args) {
		 
		PublicSectorBank psb= new PublicSectorBank();
		psb.withdrawAmount();
		psb.depositAmount();
		System.out.println(psb.applyCreditCard());
		 psb.takeInsurance();
		
		//------------------
		
		PrivateBank pb= new PrivateBank();
		pb.depositAmount();
		pb.withdrawAmount();
		System.out.println(pb.applyCreditCard());
		 

	}

}
