package student;

public class StudentMain {

	public static void main(String[] args) {
		 	// this will invoke default cons
		Student stu1= new Student();
		System.out.println(stu1);
		
		Student stu2= new Student(101, "student1", "Maths", 33);
		System.out.println(stu2);
	}

}
