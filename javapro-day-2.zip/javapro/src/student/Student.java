package student;

public class Student {

	// initialize the properties

	private int studentRole;
	private String studentName;
	private String subject;
	private int marks;

	// default cons
	public Student() {
		studentRole = 0;
		studentName = "unknown";
	}

	// parameter cons
	public Student(int studentRole, String studentName, String subject, int marks) {
		super();
		this.studentRole = studentRole;
		this.studentName = studentName;
		this.subject = subject;
		this.marks = marks;
	}

	@Override
	public String toString() {
		return "Student [studentRole=" + studentRole + ", studentName=" + studentName + ", subject=" + subject
				+ ", marks=" + marks + "]";
	}
	
	

}
