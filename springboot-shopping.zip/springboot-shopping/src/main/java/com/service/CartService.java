package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Cart;
import com.repo.CartRepo;
@Service
public class CartService {
	@Autowired
	private CartRepo repo;
	
	public Cart addToCart(Cart cart) {
		return repo.save(cart);
	}
	public List<Cart> getCartItems(){
		return (List<Cart>) repo.findAll();
	}

}
