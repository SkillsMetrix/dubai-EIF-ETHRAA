package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.model.Product;
import com.repo.ProductRepo;

@Service
public class ProductService {
	@Autowired
	private ProductRepo repo;
	
	private String URL="https://fakestoreapi.com/products";
	
	public List<Product> loadProducts(){
		RestTemplate template= new RestTemplate();
		Product[] products= template.getForObject(URL, Product[].class);
		repo.saveAll(List.of(products));
		return (List<Product>) repo.findAll();
	}
	
	public List<Product> getProduct() {
		return (List<Product>) repo.findAll();
	}

}
