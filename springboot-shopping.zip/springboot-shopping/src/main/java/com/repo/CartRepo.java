package com.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.model.Cart;
import com.model.Product;
@Repository
public interface CartRepo extends CrudRepository<Cart, Integer>{

}
