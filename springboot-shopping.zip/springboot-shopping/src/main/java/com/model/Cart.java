package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Cart {
	@Id
	@GeneratedValue
	private Long cartId;
	private Long productId;
	private String title;
	private Double price;
	private Integer quantity;
	private String image;
	
	
	public Cart(Long cartId, Long productId, String title, Double price, Integer quantity, String image) {
		super();
		this.cartId = cartId;
		this.productId = productId;
		this.title = title;
		this.price = price;
		this.quantity = quantity;
		this.image = image;
	}


	public Long getCartId() {
		return cartId;
	}


	public void setCartId(Long cartId) {
		this.cartId = cartId;
	}


	public Long getProductId() {
		return productId;
	}


	public void setProductId(Long productId) {
		this.productId = productId;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public Double getPrice() {
		return price;
	}


	public void setPrice(Double price) {
		this.price = price;
	}


	public Integer getQuantity() {
		return quantity;
	}


	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}


	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
