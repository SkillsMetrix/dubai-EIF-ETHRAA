package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Product;
import com.service.ProductService;

@RestController
@RequestMapping("/products")
@CrossOrigin("*")
public class ProductApp {
	@Autowired
	private ProductService service;
	
	@GetMapping("/load")
	public List<Product> loadProduct(){
		return service.loadProducts();
		
	}
	@GetMapping
	public List<Product> getProduct(){
		return service.getProduct();
		
	}
		
	}
	
	


