package com.bank.service;

import com.bank.entity.Account;

import com.bank.exception
        .AccountNotFoundException;

import com.bank.exception
        .InsufficientBalanceException;

import com.bank.exception
        .InvalidCredentialsException;

import com.bank.repository.AccountRepository;

import org.springframework.beans.factory.annotation
        .Autowired;

import org.springframework.stereotype.Service;

@Service
public class AccountService {

    @Autowired
    private AccountRepository repository;

    public Account register(
            Account account) {

        account.setBalance(0.0);

        return repository.save(account);
    }

    public Account login(
            String username,
            String password) {

        Account account =
                repository
                .findByUsernameAndPassword(
                        username,
                        password
                );

        if(account == null) {

            throw new
                    InvalidCredentialsException(
                    "Invalid Credentials"
            );
        }

        return account;
    }

    public Account deposit(
            Long id,
            Double amount) {

        Account account =
                repository.findById(id)
                .orElseThrow(() ->
                        new
                        AccountNotFoundException(
                                "Account Not Found"
                        )
                );

        account.setBalance(
                account.getBalance() + amount
        );

        return repository.save(account);
    }

    public Account withdraw(
            Long id,
            Double amount) {

        Account account =
                repository.findById(id)
                .orElseThrow(() ->
                        new
                        AccountNotFoundException(
                                "Account Not Found"
                        )
                );

        if(account.getBalance() < amount) {

            throw new
                    InsufficientBalanceException(
                    "Insufficient Balance"
            );
        }

        account.setBalance(
                account.getBalance() - amount
        );

        return repository.save(account);
    }
}