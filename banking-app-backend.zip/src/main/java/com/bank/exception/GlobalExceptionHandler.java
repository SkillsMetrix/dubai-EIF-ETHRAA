package com.bank.exception;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation
        .ExceptionHandler;

import org.springframework.web.bind.annotation
        .RestControllerAdvice;

import java.time.LocalDateTime;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(
            InvalidCredentialsException.class
    )
    public ResponseEntity<ErrorResponse>
    handleInvalidCredentials(
            InvalidCredentialsException ex) {

        ErrorResponse response =
                new ErrorResponse(
                        ex.getMessage(),
                        401,
                        LocalDateTime.now()
                );

        return new ResponseEntity<>(
                response,
                HttpStatus.UNAUTHORIZED
        );
    }

    @ExceptionHandler(
            InsufficientBalanceException.class
    )
    public ResponseEntity<ErrorResponse>
    handleInsufficientBalance(
            InsufficientBalanceException ex) {

        ErrorResponse response =
                new ErrorResponse(
                        ex.getMessage(),
                        400,
                        LocalDateTime.now()
                );

        return new ResponseEntity<>(
                response,
                HttpStatus.BAD_REQUEST
        );
    }

    @ExceptionHandler(
            AccountNotFoundException.class
    )
    public ResponseEntity<ErrorResponse>
    handleAccountNotFound(
            AccountNotFoundException ex) {

        ErrorResponse response =
                new ErrorResponse(
                        ex.getMessage(),
                        404,
                        LocalDateTime.now()
                );

        return new ResponseEntity<>(
                response,
                HttpStatus.NOT_FOUND
        );
    }
}